/* Author: Jay Atkins
# Date: 3/29/2019

LEGAL DISCLAIMER
This Sample Code is provided for the purpose of illustration only and is not
intended to be used in a production environment.  THIS SAMPLE CODE AND ANY
RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  We grant You a
nonexclusive, royalty-free right to use and modify the Sample Code and to
reproduce and distribute the object code form of the Sample Code, provided
that You agree: (i) to not use Our name, logo, or trademarks to market Your
software product in which the Sample Code is embedded; (ii) to include a valid
copyright notice on Your software product in which the Sample Code is embedded;
and (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and
against any claims or lawsuits, including attorneys’ fees, that arise or result
from the use or distribution of the Sample Code.

This posting is provided "AS IS" with no warranties, and confers no rights. Use
of included script samples are subject to the terms specified
at http://www.microsoft.com/info/cpyright.htm.

#Prerequisites

# 1.  Create the appropriate app registrations with and get the app id and secret (generate this in the portal)
# 2.  Get the endpoints from the app registration configuration for your tenant (AppRegistrations->Endpoints button)
# 3.  Setup the redirect uris.  These flows will not work without valid redirect uris and you will get errors as such

#Notes:

# 1. This is pretty rough code that needs some clean up with exception handling and response code handling. This sample is only supposed to show the base implementation of
getting auth tokens for a resource in Azure using ADAL4J
# 2. Device Code flow (not implemented)
# 3. Native code flows are in the native project


 */
package com.nerdplanet;

import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Controller
public class HomeController {

    private final static String AUTHORITY = "https://login.microsoftonline.com/[your tenant}/";
    private final static String CLIENT_ID = "{application id}";
    private final static String ACCESS_KEY = "{application secret";
    private final static String TENANT_ID = "{tenant id}";
    private final static String RESOURCE_URI = "https://graph.microsoft.com";
    private final static String REDIRECT_URI = "http://localhost:8080/Java_Web_war_exploded/authCodeResult";

    //This method can be used with a Web app/api application in Azure
    //The Client Credentials grant type is used by clients to obtain an access token outside of the context of a user.
    //This is typically used by clients to access resources about themselves rather than to access a user's resources.
    @RequestMapping("/clientCredentials")
    public String getTokenWithClientCredentials(ModelMap model) {

        AuthenticationResult result = getAccessTokenFromClientCredentials();

        model.addAttribute("token", result.getAccessToken());
        return "Home";
    }

    //This method gets and auth code and then uses that code to get a token for a resource.
    //The Authorization Code grant type is used by confidential and public clients to exchange an authorization code for an access token.
    //After the user returns to the client via the redirect URL, the application will get the authorization code from the URL and use it to request an access token.
    //This flow is the replacement for the implict flow that should no longer be used
    @RequestMapping("/authCode")
    public String getAuthCode(ModelMap model) throws Exception {

        StringBuilder auth_code_request = new StringBuilder();

        //Construct the base uri
        auth_code_request.append("https://login.microsoftonline.com/");
        auth_code_request.append(TENANT_ID);  //This can be found in the endpoints section of the app registrations
        auth_code_request.append("/oauth2/authorize");

        //Construct the query string
        auth_code_request.append("?client_id=");
        auth_code_request.append(CLIENT_ID);
        auth_code_request.append("&response_type=code"); //We are requesting an auth code for use in subsequent requests
        auth_code_request.append("&redirect_uri=http://localhost:8080/Java_Web_war_exploded/authCodeResult"); //This uri must match a uri that was set during the app registration
        auth_code_request.append("&response_mode=query");
        auth_code_request.append("&resource=https://graph.microsoft.com"); //This is the resource I want access to
        auth_code_request.append("&state=12345");  //This should be a randomly generated value and not static like this

        return "redirect:" + auth_code_request.toString();
    }

    @RequestMapping("/authCodeResult")
    public String getTokenWithAuthCode(@RequestParam("code") String code, ModelMap model) throws Exception {

        //The auth code is returned here and gets set in the query string
        AuthenticationResult result = getAccessTokenFromAuthorizationCode(code);

        model.addAttribute("token", result.getAccessToken());

        return "Home";
    }

    //The Password grant type is used by first-party clients to exchange a user's credentials for an access token.
    //Since this involves the client asking the user for their password, it should not be used by third party clients.
    //In this flow, the user's username and password are exchanged directly for an access token.
    //THIS METHOD IS for NATIVE CLIENTS and will not work int the near future.  (See native sample project)

    //The Resource Owner Password Credentials Grant flow for confidential clients (which is what you are trying to invoke with a client ID, client secret, username and password)
    //is not a supported flow with Azure AD. (It will soon stop working on the service side, even if you try manually craft the request.)
    // This flow is only supported for apps registered as native clients (i.e. public clients, in OAuth 2.0 terminology), which don't have client credentials.
    // (Again: you don't want to do that in a web app.).  This method wont actually work, but I'm including it here
    @RequestMapping("/password")
    public String getTokenWithPassword(ModelMap model) throws Exception {
        //The auth code is returned here and gets set in the query string
        AuthenticationResult result = getAccessTokenFromPassword("some@user.com", "somepassword");

        model.addAttribute("token", result.getAccessToken());

        return "Home";
    }

    //The OAuth 2.0 On-Behalf-Of (OBO) flow enables an application that invokes a service or web API to pass user authentication to another service or web API.
    //The OBO flow propagates the delegated user identity and permissions through the request chain. For the middle-tier service to make authenticated requests to the
    // downstream service, it must secure an access token from Azure Active Directory (Azure AD) on behalf of the user.
    //https://docs.microsoft.com/en-us/azure/active-directory/develop/v1-oauth2-on-behalf-of-flow
    @RequestMapping("/onBehalfOf")
    public String getTokenOnBehalfOf(ModelMap model) throws Exception {

        //This flow starts with the AuthCode Flow
        StringBuilder auth_code_request = new StringBuilder();

        //Construct the base uri
        auth_code_request.append("https://login.microsoftonline.com/");
        auth_code_request.append(TENANT_ID);  //This can be found in the endpoints section of the app registrations
        auth_code_request.append("/oauth2/authorize");

        //Construct the query string
        auth_code_request.append("?client_id=");
        auth_code_request.append(CLIENT_ID);
        auth_code_request.append("&response_type=code"); //We are requesting an auth code for use in subsequent requests
        auth_code_request.append("&redirect_uri=http://localhost:8080/Java_Web_war_exploded/authCodeResult"); //This uri must match a uri that was set during the app registration
        auth_code_request.append("&response_mode=query");
        auth_code_request.append("&resource=https://graph.microsoft.com"); //This is the resource I want access to
        auth_code_request.append("&state=12345");  //This should be a randomly generated value and not static like this

        return "redirect:" + auth_code_request.toString();

        //The client application makes a request to API A with the token A.
        //API A authenticates to the Azure AD token issuance endpoint and requests a token to access API B.
        //The Azure AD token issuance endpoint validates API A's credentials with token A and issues the access token for API B (token B).
        //The request to API B contains token B in the authorization header.
        //API B returns data from the secured resource.
        //model.addAttribute("token", result.getAccessToken());

        //Todo: Complete this flow and registrations https://docs.microsoft.com/en-us/azure/active-directory/develop/v1-oauth2-on-behalf-of-flow

    }

    public static AuthenticationResult getAccessTokenFromPassword(String userName, String password) throws MalformedURLException, ExecutionException, InterruptedException {
        ExecutorService service = Executors.newFixedThreadPool(1);
        AuthenticationContext context = new AuthenticationContext(AUTHORITY, true, service);

        //There are a number of overloads to this method.  If
        final Future<AuthenticationResult> authenticationResultFuture = context.acquireToken((RESOURCE_URI, CLIENT_ID, userName, password, null);
        return authenticationResultFuture.get();
    }

    public static AuthenticationResult getAccessTokenFromAuthorizationCode(String code) throws ExecutionException, InterruptedException, IOException, URISyntaxException {

        ExecutorService service = Executors.newFixedThreadPool(1);
        AuthenticationContext context = new AuthenticationContext(AUTHORITY, true, service);

        URI redirectUri = new URI(REDIRECT_URI);

        ClientCredential credential = new ClientCredential(CLIENT_ID, ACCESS_KEY);

        //There are a number of overloads to this method.  If
        final Future<AuthenticationResult> authenticationResultFuture = context.acquireTokenByAuthorizationCode(code, redirectUri, credential, RESOURCE_URI, null);
        return authenticationResultFuture.get();
    }

        //Client Credentials can be used for confidential clients (Service to Service calls)
    public static AuthenticationResult getAccessTokenFromClientCredentials(){
        AuthenticationContext context;
        ExecutorService service = null;
        try {
            service = Executors.newFixedThreadPool(1);
            context = new AuthenticationContext(AUTHORITY, false, service);

            ClientCredential credential = new ClientCredential(CLIENT_ID, ACCESS_KEY);
            Future<AuthenticationResult> future = context.acquireToken(RESOURCE_URI, credential,null);
            return future.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } finally {
            service.shutdown();
        }

        return null;
    }
}
